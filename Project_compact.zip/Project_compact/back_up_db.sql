-- MySQL dump 10.13  Distrib 5.7.26, for Linux (x86_64)
--
-- Host: localhost    Database: gym_db
-- ------------------------------------------------------
-- Server version	5.7.26-0ubuntu0.18.10.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Cliente`
--

DROP TABLE IF EXISTS `Cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cliente` (
  `idCliente` int(11) NOT NULL,
  `nombre` varchar(45) DEFAULT NULL,
  `fecha_nacimiento` date NOT NULL,
  PRIMARY KEY (`idCliente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cliente`
--

LOCK TABLES `Cliente` WRITE;
/*!40000 ALTER TABLE `Cliente` DISABLE KEYS */;
INSERT INTO `Cliente` VALUES (603498904,'Sofia Ascaray','2002-04-29'),(603946723,'Carlos Tauro','1980-12-10'),(657889439,'Diego Coloma','1996-05-30'),(749083456,'Leana Atre','1995-09-01'),(1020394857,'Emilia Castillo','2001-05-01'),(1718655333,'Jonathan Cazco','1998-09-24'),(1726544888,'Sofia Ascaray','2000-10-10'),(1739844555,'Esteban Acurio','1992-09-18'),(1739908777,'John Castro','1995-06-09'),(1787677333,'Martin Freire','1998-04-12');
/*!40000 ALTER TABLE `Cliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Dieta`
--

DROP TABLE IF EXISTS `Dieta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Dieta` (
  `idEmpleado` int(11) NOT NULL,
  `idCliente` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `duracion_d` int(11) DEFAULT NULL,
  `recomendaciones` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`idEmpleado`,`idCliente`,`fecha`),
  KEY `fk_Empleado_has_Cliente1_Cliente1_idx` (`idCliente`),
  KEY `fk_Empleado_has_Cliente1_Empleado1_idx` (`idEmpleado`),
  CONSTRAINT `fk_Empleado_has_Cliente1_Cliente1` FOREIGN KEY (`idCliente`) REFERENCES `Cliente` (`idCliente`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Empleado_has_Cliente1_Empleado1` FOREIGN KEY (`idEmpleado`) REFERENCES `Empleado` (`idEmpleado`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Dieta`
--

LOCK TABLES `Dieta` WRITE;
/*!40000 ALTER TABLE `Dieta` DISABLE KEYS */;
INSERT INTO `Dieta` VALUES (1718677888,1718655333,'2019-06-13',90,'Dieta baja en grasa y alta en proteina'),(1718677888,1718655333,'2019-09-14',60,'Dieta baja en grasa y alta en proteina, aumenta carbo'),(1718677888,1718655333,'2019-11-12',20,'Grasa saludables, doble proteina y carbo para entrenamiento'),(1718677888,1726544888,'2019-06-23',120,'Carbohidratos y proteinas'),(1718677888,1726544888,'2019-10-15',30,'Proteina y batidos para moldear');
/*!40000 ALTER TABLE `Dieta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Empleado`
--

DROP TABLE IF EXISTS `Empleado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Empleado` (
  `idEmpleado` int(11) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `edad` int(11) NOT NULL,
  `titulo` varchar(45) NOT NULL,
  PRIMARY KEY (`idEmpleado`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Empleado`
--

LOCK TABLES `Empleado` WRITE;
/*!40000 ALTER TABLE `Empleado` DISABLE KEYS */;
INSERT INTO `Empleado` VALUES (1718677888,'German Guerra',28,'Nutricionista'),(1719422238,'Marco Yanez',33,'PT ; Fisioterapeuta');
/*!40000 ALTER TABLE `Empleado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Entrenador`
--

DROP TABLE IF EXISTS `Entrenador`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Entrenador` (
  `idEntrenador` int(11) NOT NULL AUTO_INCREMENT,
  `idEmpleado` int(11) NOT NULL,
  `idCliente` int(11) NOT NULL,
  `especialidad` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idEntrenador`),
  KEY `fk_Empleado_has_Cliente_Cliente1_idx` (`idCliente`),
  KEY `fk_Empleado_has_Cliente_Empleado1_idx` (`idEmpleado`),
  CONSTRAINT `fk_Empleado_has_Cliente_Cliente1` FOREIGN KEY (`idCliente`) REFERENCES `Cliente` (`idCliente`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Empleado_has_Cliente_Empleado1` FOREIGN KEY (`idEmpleado`) REFERENCES `Empleado` (`idEmpleado`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=104 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Entrenador`
--

LOCK TABLES `Entrenador` WRITE;
/*!40000 ALTER TABLE `Entrenador` DISABLE KEYS */;
INSERT INTO `Entrenador` VALUES (101,1719422238,1718655333,'Body building'),(102,1719422238,1726544888,'Body shape'),(103,1719422238,657889439,'Saltabilidad');
/*!40000 ALTER TABLE `Entrenador` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Equipos`
--

DROP TABLE IF EXISTS `Equipos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Equipos` (
  `idEquipos` int(11) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `descripcion` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idEquipos`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Equipos`
--

LOCK TABLES `Equipos` WRITE;
/*!40000 ALTER TABLE `Equipos` DISABLE KEYS */;
INSERT INTO `Equipos` VALUES (11,'compresor pecho','compresor de pecho multiangulo'),(12,'flyer','extensiones pecho/biceps/triceps'),(13,'compresor hombros','compresor de hombros multiangulo'),(15,'mancuerna','mancuerna multiples pesos'),(31,'abdominales','abdominales multiangulo');
/*!40000 ALTER TABLE `Equipos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Factura`
--

DROP TABLE IF EXISTS `Factura`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Factura` (
  `idPago` int(11) NOT NULL AUTO_INCREMENT,
  `idMenbresia` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `valor` decimal(10,2) NOT NULL,
  PRIMARY KEY (`idPago`,`idMenbresia`),
  KEY `fk_Pagos_Membresia1` (`idMenbresia`),
  CONSTRAINT `fk_Pagos_Membresia1` FOREIGN KEY (`idMenbresia`) REFERENCES `Membresia` (`idMenbresia`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Factura`
--

LOCK TABLES `Factura` WRITE;
/*!40000 ALTER TABLE `Factura` DISABLE KEYS */;
/*!40000 ALTER TABLE `Factura` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Fisioterapia`
--

DROP TABLE IF EXISTS `Fisioterapia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Fisioterapia` (
  `idEmpleado` int(11) NOT NULL,
  `idCliente` int(11) NOT NULL,
  `tratamiento` varchar(90) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  PRIMARY KEY (`idEmpleado`,`idCliente`),
  KEY `fk_Empleado_has_Cliente2_Cliente1_idx` (`idCliente`),
  KEY `fk_Empleado_has_Cliente2_Empleado1_idx` (`idEmpleado`),
  CONSTRAINT `fk_Empleado_has_Cliente2_Cliente1` FOREIGN KEY (`idCliente`) REFERENCES `Cliente` (`idCliente`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Empleado_has_Cliente2_Empleado1` FOREIGN KEY (`idEmpleado`) REFERENCES `Empleado` (`idEmpleado`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Fisioterapia`
--

LOCK TABLES `Fisioterapia` WRITE;
/*!40000 ALTER TABLE `Fisioterapia` DISABLE KEYS */;
INSERT INTO `Fisioterapia` VALUES (1719422238,603946723,'Rodilla saltador','2019-07-18'),(1719422238,657889439,'Tendones hombro','2019-08-23'),(1719422238,1739908777,'Escoleosis','2019-10-20');
/*!40000 ALTER TABLE `Fisioterapia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Gimnasio`
--

DROP TABLE IF EXISTS `Gimnasio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Gimnasio` (
  `idGimnasio` int(11) NOT NULL AUTO_INCREMENT,
  `sucursal` varchar(45) DEFAULT NULL,
  `direccion` varchar(45) DEFAULT NULL,
  `num_clientes` int(11) DEFAULT NULL,
  PRIMARY KEY (`idGimnasio`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Gimnasio`
--

LOCK TABLES `Gimnasio` WRITE;
/*!40000 ALTER TABLE `Gimnasio` DISABLE KEYS */;
INSERT INTO `Gimnasio` VALUES (1,'Labrador','Amazonas y Zamora',10);
/*!40000 ALTER TABLE `Gimnasio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Inventario`
--

DROP TABLE IF EXISTS `Inventario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Inventario` (
  `idInventario` int(11) NOT NULL,
  `idGimnasio` int(11) NOT NULL,
  `idEquipos` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  PRIMARY KEY (`idInventario`,`idGimnasio`,`idEquipos`),
  KEY `fk_Gimnasio_has_Equipos_Equipos1_idx` (`idEquipos`),
  KEY `fk_Gimnasio_has_Equipos_Gimnasio_idx` (`idGimnasio`),
  CONSTRAINT `fk_Gimnasio_has_Equipos_Equipos1` FOREIGN KEY (`idEquipos`) REFERENCES `Equipos` (`idEquipos`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Gimnasio_has_Equipos_Gimnasio` FOREIGN KEY (`idGimnasio`) REFERENCES `Gimnasio` (`idGimnasio`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Inventario`
--

LOCK TABLES `Inventario` WRITE;
/*!40000 ALTER TABLE `Inventario` DISABLE KEYS */;
INSERT INTO `Inventario` VALUES (11,1,11,2),(11,1,12,2),(11,1,13,1),(11,1,15,10),(11,1,31,3);
/*!40000 ALTER TABLE `Inventario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Localizacion`
--

DROP TABLE IF EXISTS `Localizacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Localizacion` (
  `idLocalizacion` int(11) NOT NULL,
  `idEquipos` int(11) NOT NULL,
  `musculo` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idLocalizacion`),
  KEY `fk_Localizacion_Equipos1_idx` (`idEquipos`),
  CONSTRAINT `fk_Localizacion_Equipos1` FOREIGN KEY (`idEquipos`) REFERENCES `Equipos` (`idEquipos`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Localizacion`
--

LOCK TABLES `Localizacion` WRITE;
/*!40000 ALTER TABLE `Localizacion` DISABLE KEYS */;
INSERT INTO `Localizacion` VALUES (11,11,'Pecho Bajo'),(12,11,'Pecho Medio'),(13,11,'Biceps'),(14,12,'Triceps'),(15,12,'Pecho Medio'),(16,13,'Hombros'),(17,13,'Espalda'),(18,15,'Triceps'),(19,15,'Biceps'),(31,31,'Abdomen'),(110,15,'Deltoides');
/*!40000 ALTER TABLE `Localizacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Medidas`
--

DROP TABLE IF EXISTS `Medidas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Medidas` (
  `idMedidas` date NOT NULL,
  `idCliente` int(11) NOT NULL,
  `imc` decimal(10,2) DEFAULT NULL,
  `altura` decimal(10,2) DEFAULT NULL,
  `peso` decimal(10,2) DEFAULT NULL,
  `p_grasa` decimal(10,2) DEFAULT NULL,
  `p_musculo` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`idMedidas`,`idCliente`),
  KEY `fk_Medidas_Cliente1_idx` (`idCliente`),
  CONSTRAINT `fk_Medidas_Cliente1` FOREIGN KEY (`idCliente`) REFERENCES `Cliente` (`idCliente`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Medidas`
--

LOCK TABLES `Medidas` WRITE;
/*!40000 ALTER TABLE `Medidas` DISABLE KEYS */;
INSERT INTO `Medidas` VALUES ('2019-06-12',1718655333,26.50,184.00,90.60,30.50,33.50),('2019-06-20',1726544888,25.00,175.00,76.50,20.00,20.00),('2019-07-12',1718655333,25.50,184.00,86.60,29.60,33.80),('2019-07-20',1726544888,24.80,175.00,73.30,19.80,22.40),('2019-08-12',1718655333,25.50,184.00,88.40,29.40,34.10),('2019-08-20',1726544888,23.30,175.00,73.00,19.20,22.90),('2019-09-12',1718655333,25.00,184.00,85.40,26.40,35.80),('2019-09-20',1726544888,22.40,175.00,72.10,18.30,23.50),('2019-10-12',1718655333,24.80,184.00,85.00,26.80,35.60),('2019-11-12',1718655333,24.60,184.00,84.30,24.30,37.20);
/*!40000 ALTER TABLE `Medidas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Membresia`
--

DROP TABLE IF EXISTS `Membresia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Membresia` (
  `idMenbresia` int(11) NOT NULL AUTO_INCREMENT,
  `idGimnasio` int(11) NOT NULL,
  `idCliente` int(11) NOT NULL,
  `Duracion_mes` int(11) NOT NULL,
  `fecha_r` date NOT NULL,
  PRIMARY KEY (`idMenbresia`),
  KEY `fk_Gimnasio_has_Cliente_Cliente1_idx` (`idCliente`),
  KEY `fk_Gimnasio_has_Cliente_Gimnasio1_idx` (`idGimnasio`),
  CONSTRAINT `fk_Gimnasio_has_Cliente_Cliente1` FOREIGN KEY (`idCliente`) REFERENCES `Cliente` (`idCliente`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Gimnasio_has_Cliente_Gimnasio1` FOREIGN KEY (`idGimnasio`) REFERENCES `Gimnasio` (`idGimnasio`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Membresia`
--

LOCK TABLES `Membresia` WRITE;
/*!40000 ALTER TABLE `Membresia` DISABLE KEYS */;
INSERT INTO `Membresia` VALUES (1,1,603498904,3,'2019-07-03'),(2,1,603946723,3,'2019-08-08'),(3,1,657889439,3,'2019-01-07'),(4,1,749083456,6,'2019-03-04'),(5,1,1020394857,1,'2019-07-07'),(6,1,1718655333,12,'2019-06-12'),(7,1,1726544888,12,'2019-06-12'),(8,1,1739844555,3,'2019-10-09'),(9,1,1739908777,6,'2019-11-24'),(10,1,1787677333,9,'2019-02-20');
/*!40000 ALTER TABLE `Membresia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Nomina`
--

DROP TABLE IF EXISTS `Nomina`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Nomina` (
  `idEmpleado` int(11) NOT NULL,
  `idGimnasio` int(11) NOT NULL,
  `sueldo` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`idEmpleado`,`idGimnasio`),
  KEY `fk_Empleado_has_Gimnasio_Gimnasio1_idx` (`idGimnasio`),
  KEY `fk_Empleado_has_Gimnasio_Empleado1_idx` (`idEmpleado`),
  CONSTRAINT `fk_Empleado_has_Gimnasio_Empleado1` FOREIGN KEY (`idEmpleado`) REFERENCES `Empleado` (`idEmpleado`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Empleado_has_Gimnasio_Gimnasio1` FOREIGN KEY (`idGimnasio`) REFERENCES `Gimnasio` (`idGimnasio`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Nomina`
--

LOCK TABLES `Nomina` WRITE;
/*!40000 ALTER TABLE `Nomina` DISABLE KEYS */;
INSERT INTO `Nomina` VALUES (1718677888,1,400.60),(1719422238,1,750.70);
/*!40000 ALTER TABLE `Nomina` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Rutina`
--

DROP TABLE IF EXISTS `Rutina`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Rutina` (
  `idEntrenador` int(11) NOT NULL,
  `idLocalizacion` int(11) NOT NULL,
  `series` int(11) DEFAULT NULL,
  `repeticiones` int(11) DEFAULT NULL,
  `fecha_r` date DEFAULT NULL,
  PRIMARY KEY (`idEntrenador`,`idLocalizacion`),
  KEY `fk_Rutina_Localizacion1_idx` (`idLocalizacion`),
  CONSTRAINT `fk_Rutina_Entrenador1` FOREIGN KEY (`idEntrenador`) REFERENCES `Entrenador` (`idEntrenador`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Rutina_Localizacion1` FOREIGN KEY (`idLocalizacion`) REFERENCES `Localizacion` (`idLocalizacion`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Rutina`
--

LOCK TABLES `Rutina` WRITE;
/*!40000 ALTER TABLE `Rutina` DISABLE KEYS */;
INSERT INTO `Rutina` VALUES (101,11,4,15,'2019-09-20'),(101,12,4,15,'2019-09-20'),(101,13,4,10,'2019-09-20'),(101,16,4,15,'2019-09-20'),(101,17,4,10,'2019-09-20'),(101,18,4,15,'2019-09-20'),(101,19,4,20,'2019-09-20'),(101,31,4,100,'2019-09-20'),(101,110,4,20,'2019-09-20');
/*!40000 ALTER TABLE `Rutina` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-11-29 18:12:41
