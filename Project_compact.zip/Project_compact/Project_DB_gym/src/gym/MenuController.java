package gym;

import java.io.IOException;

import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Tab;

public class MenuController {
	
	Parent info_tab;
	
	@FXML
	private Tab informacionTab;
	@FXML
	private Tab rutinasTab;
	
	@FXML
	public void tabPressed(Event e) {
		
		try {
			
			info_tab = FXMLLoader.load(getClass().getResource("cliente_informacion.fxml"));
			informacionTab.setContent(info_tab);
			
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		
	}
	

}
