package gym;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class MainController {
	
	private Stage parentStage;
	
	@FXML
	public void actionStartButton(ActionEvent e) {
		
		Parent menu;
		
		try {
			
			parentStage = (Stage)((Node)(e.getSource())).getScene().getWindow();
			
			menu = FXMLLoader.load(getClass().getResource("global_menu.fxml"));
	        
			Scene scene = new Scene(menu);
	        Stage appStage = new Stage();
	        
	        appStage.setScene(scene);
	        
	        parentStage.close();
	        appStage.show();
	        
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		
	}
	
	
}
